

let kelvin = prompt('What is the temperatue today in kelvin?');  // todays temperature in kelvin

let celsius = kelvin - 273 ; //today temp in Celsius

let fahrenhiet = celsius * (9/5) + 32;

fahrenhiet = Math.round(fahrenhiet);

console.log(`The temperature is ${fahrenhiet} in Fahrenheit. `);

alert(`The temperature is ${fahrenhiet} in Fahrenheit today, then! `);

